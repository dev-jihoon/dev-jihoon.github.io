
# THIS FILE IS GENERATED FROM ORANGE SETUP.PY
short_version = '3.41.0'
version = '3.41.0'
full_version = '3.41.0'
git_revision = '46443558d61d869541a5d987b3ac06b05f2a1015'
release = True

if not release:
    version = full_version
    short_version += ".dev"
