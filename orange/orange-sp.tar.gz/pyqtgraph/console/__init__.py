from .Console import ConsoleWidget
